#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include <pthread.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/mount.h>
#include <sched.h>

#define MAX_CONTAINERS 16
#define LOG_BUFFER_SIZE 64
#define LOG_ENTRY_SIZE 512
#define SOCKET_PATH "/tmp/engine.sock"
#define LOG_DIR "/tmp/container_logs"

typedef enum {
    STATE_STARTING, STATE_RUNNING, STATE_STOPPED, STATE_KILLED
} ContainerState;

typedef struct {
    char id[64];
    pid_t host_pid;
    time_t start_time;
    ContainerState state;
    long soft_limit_mb;
    long hard_limit_mb;
    char log_path[256];
    int exit_status;
    int log_pipe[2];
    int active;
} Container;

typedef struct {
    char entries[LOG_BUFFER_SIZE][LOG_ENTRY_SIZE];
    int head, tail, count;
    pthread_mutex_t mutex;
    pthread_cond_t not_empty;
    pthread_cond_t not_full;
} LogBuffer;

static Container containers[MAX_CONTAINERS];
static pthread_mutex_t containers_mutex = PTHREAD_MUTEX_INITIALIZER;
static LogBuffer log_buffer;
static volatile int supervisor_running = 1;
static pthread_t log_consumer_thread;

/* ── bounded buffer (Task 3) ── */
void log_buffer_init(void) {
    memset(&log_buffer, 0, sizeof(log_buffer));
    pthread_mutex_init(&log_buffer.mutex, NULL);
    pthread_cond_init(&log_buffer.not_empty, NULL);
    pthread_cond_init(&log_buffer.not_full, NULL);
}

void log_buffer_push(const char *entry) {
    pthread_mutex_lock(&log_buffer.mutex);
    while (log_buffer.count == LOG_BUFFER_SIZE)
        pthread_cond_wait(&log_buffer.not_full, &log_buffer.mutex);
    strncpy(log_buffer.entries[log_buffer.tail], entry, LOG_ENTRY_SIZE - 1);
    log_buffer.tail = (log_buffer.tail + 1) % LOG_BUFFER_SIZE;
    log_buffer.count++;
    pthread_cond_signal(&log_buffer.not_empty);
    pthread_mutex_unlock(&log_buffer.mutex);
}

int log_buffer_pop(char *out) {
    pthread_mutex_lock(&log_buffer.mutex);
    while (log_buffer.count == 0 && supervisor_running)
        pthread_cond_wait(&log_buffer.not_empty, &log_buffer.mutex);
    if (log_buffer.count == 0) {
        pthread_mutex_unlock(&log_buffer.mutex);
        return 0;
    }
    strncpy(out, log_buffer.entries[log_buffer.head], LOG_ENTRY_SIZE - 1);
    log_buffer.head = (log_buffer.head + 1) % LOG_BUFFER_SIZE;
    log_buffer.count--;
    pthread_cond_signal(&log_buffer.not_full);
    pthread_mutex_unlock(&log_buffer.mutex);
    return 1;
}

void *log_consumer(void *arg) {
    (void)arg;
    char entry[LOG_ENTRY_SIZE];
    while (supervisor_running || log_buffer.count > 0) {
        if (!log_buffer_pop(entry)) break;
        char *sep = strchr(entry, '|');
        if (!sep) continue;
        *sep = '\0';
        FILE *f = fopen(entry, "a");
        if (f) { fputs(sep + 1, f); fclose(f); }
    }
    return NULL;
}

void *log_producer(void *arg) {
    Container *c = (Container *)arg;
    char buf[512], entry[LOG_ENTRY_SIZE];
    ssize_t n;
    while ((n = read(c->log_pipe[0], buf, sizeof(buf) - 1)) > 0) {
        buf[n] = '\0';
        snprintf(entry, sizeof(entry), "%s|%s", c->log_path, buf);
        log_buffer_push(entry);
    }
    close(c->log_pipe[0]);
    return NULL;
}

/* ── signal handlers ── */
static void sigchld_handler(int sig) {
    (void)sig;
    int status; pid_t pid;
    while ((pid = waitpid(-1, &status, WNOHANG)) > 0) {
        pthread_mutex_lock(&containers_mutex);
        for (int i = 0; i < MAX_CONTAINERS; i++) {
            if (containers[i].active && containers[i].host_pid == pid) {
                containers[i].exit_status = WEXITSTATUS(status);
                containers[i].state = STATE_STOPPED;
                break;
            }
        }
        pthread_mutex_unlock(&containers_mutex);
    }
}

static void sigterm_handler(int sig) {
    (void)sig;
    supervisor_running = 0;
    pthread_cond_broadcast(&log_buffer.not_empty);
}

int find_free_slot(void) {
    for (int i = 0; i < MAX_CONTAINERS; i++)
        if (!containers[i].active) return i;
    return -1;
}

int find_container(const char *id) {
    for (int i = 0; i < MAX_CONTAINERS; i++)
        if (containers[i].active && strcmp(containers[i].id, id) == 0)
            return i;
    return -1;
}

/* ── Task 1: launch container ── */
int launch_container(const char *id, const char *rootfs,
                     const char *cmd, int foreground,
                     long soft_mb, long hard_mb) {
    pthread_mutex_lock(&containers_mutex);
    int slot = find_free_slot();
    if (slot < 0) {
        pthread_mutex_unlock(&containers_mutex);
        fprintf(stderr, "No free slots\n"); return -1;
    }
    Container *c = &containers[slot];
    memset(c, 0, sizeof(*c));
    strncpy(c->id, id, sizeof(c->id) - 1);
    c->soft_limit_mb = soft_mb;
    c->hard_limit_mb = hard_mb;
    c->start_time    = time(NULL);
    c->state         = STATE_STARTING;
    c->active        = 1;
    mkdir(LOG_DIR, 0755);
    snprintf(c->log_path, sizeof(c->log_path), LOG_DIR "/%s.log", id);
    if (pipe(c->log_pipe) < 0) {
        perror("pipe"); c->active = 0;
        pthread_mutex_unlock(&containers_mutex); return -1;
    }
    pthread_mutex_unlock(&containers_mutex);

    pthread_t prod_tid;
    pthread_create(&prod_tid, NULL, log_producer, c);
    pthread_detach(prod_tid);

    pid_t pid = fork();
    if (pid == 0) {
        close(c->log_pipe[0]);
        dup2(c->log_pipe[1], STDOUT_FILENO);
        dup2(c->log_pipe[1], STDERR_FILENO);
        close(c->log_pipe[1]);
        unshare(CLONE_NEWUTS | CLONE_NEWNS);
        if (chroot(rootfs) < 0) { perror("chroot"); exit(1); }
        chdir("/");
        mount("proc", "/proc", "proc", 0, NULL);
        char hostname[128];
        snprintf(hostname, sizeof(hostname), "ctr-%s", id);
        sethostname(hostname, strlen(hostname));
        execl("/bin/sh", "sh", "-c", cmd, NULL);
        perror("execl"); exit(1);
    }
    if (pid < 0) { perror("fork"); containers[slot].active = 0; return -1; }
    close(c->log_pipe[1]);

    pthread_mutex_lock(&containers_mutex);
    c->host_pid = pid;
    c->state    = STATE_RUNNING;
    pthread_mutex_unlock(&containers_mutex);

    printf("[supervisor] Container '%s' started — PID %d\n", id, pid);

    if (foreground) {
        int status;
        waitpid(pid, &status, 0);
        pthread_mutex_lock(&containers_mutex);
        c->state = STATE_STOPPED;
        c->exit_status = WEXITSTATUS(status);
        pthread_mutex_unlock(&containers_mutex);
    }
    return 0;
}

/* ── Task 2: CLI commands ── */
void cmd_ps(char *out, int out_size) {
    pthread_mutex_lock(&containers_mutex);
    int off = 0;
    off += snprintf(out+off, out_size-off,
        "\n%-16s %-8s %-10s %-10s %-10s\n",
        "ID","PID","STATE","SOFT_MB","HARD_MB");
    off += snprintf(out+off, out_size-off,
        "%-16s %-8s %-10s %-10s %-10s\n",
        "----------------","--------","----------","----------","----------");
    for (int i = 0; i < MAX_CONTAINERS; i++) {
        if (!containers[i].active) continue;
        const char *st[] = {"starting","running","stopped","killed"};
        off += snprintf(out+off, out_size-off,
            "%-16s %-8d %-10s %-10ld %-10ld\n",
            containers[i].id,
            containers[i].host_pid,
            st[containers[i].state],
            containers[i].soft_limit_mb,
            containers[i].hard_limit_mb);
    }
    pthread_mutex_unlock(&containers_mutex);
}

void cmd_stop(const char *id) {
    pthread_mutex_lock(&containers_mutex);
    int idx = find_container(id);
    if (idx < 0) { pthread_mutex_unlock(&containers_mutex); return; }
    pid_t pid = containers[idx].host_pid;
    containers[idx].state = STATE_STOPPED;
    pthread_mutex_unlock(&containers_mutex);
    kill(pid, SIGTERM);
    printf("[supervisor] Stopped container '%s' (PID %d)\n", id, pid);
}

/* ── Task 2: UNIX socket server ── */
void *cli_server(void *arg) {
    (void)arg;
    int sfd = socket(AF_UNIX, SOCK_STREAM, 0);
    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, SOCKET_PATH, sizeof(addr.sun_path)-1);
    unlink(SOCKET_PATH);
    bind(sfd, (struct sockaddr *)&addr, sizeof(addr));
    listen(sfd, 5);

    while (supervisor_running) {
        int cfd = accept(sfd, NULL, NULL);
        if (cfd < 0) continue;
        char buf[512] = {0};
        read(cfd, buf, sizeof(buf)-1);

        char response[4096] = {0};
        char c1[64]={0}, c2[128]={0}, c3[256]={0}, c4[256]={0};
        int n = sscanf(buf, "%63s %127s %255s %255s", c1, c2, c3, c4);

        if (strcmp(c1,"ps")==0) {
            cmd_ps(response, sizeof(response));
        } else if (strcmp(c1,"stop")==0 && n>=2) {
            cmd_stop(c2);
            snprintf(response, sizeof(response), "Stopped %s\n", c2);
        } else if (strcmp(c1,"logs")==0 && n>=2) {
            pthread_mutex_lock(&containers_mutex);
            int idx = find_container(c2);
            char path[256]="";
            if (idx>=0) strncpy(path, containers[idx].log_path, 255);
            pthread_mutex_unlock(&containers_mutex);
            if (path[0]) {
                FILE *f = fopen(path,"r");
                if (f) { fread(response,1,sizeof(response)-1,f); fclose(f); }
                else snprintf(response,sizeof(response),"No log yet\n");
            } else snprintf(response,sizeof(response),"Not found\n");
        } else if (strcmp(c1,"start")==0 && n>=3) {
            char cmd[256]="echo hello from container";
            if (n>=4) strncpy(cmd,c4,sizeof(cmd)-1);
            launch_container(c2, c3, cmd, 0, 128, 256);
            snprintf(response, sizeof(response), "Started %s\n", c2);
        } else {
            snprintf(response, sizeof(response), "Unknown: %s\n", c1);
        }
        write(cfd, response, strlen(response));
        close(cfd);
    }
    close(sfd); unlink(SOCKET_PATH);
    return NULL;
}

/* ── supervisor main loop ── */
void run_supervisor(const char *rootfs) {
    printf("[supervisor] Started. rootfs=%s\n", rootfs);
    struct sigaction sa;
    memset(&sa,0,sizeof(sa));
    sa.sa_handler = sigchld_handler;
    sa.sa_flags   = SA_RESTART|SA_NOCLDSTOP;
    sigaction(SIGCHLD,&sa,NULL);
    sa.sa_handler = sigterm_handler;
    sigaction(SIGTERM,&sa,NULL);
    sigaction(SIGINT, &sa,NULL);

    log_buffer_init();
    memset(containers, 0, sizeof(containers));
    pthread_create(&log_consumer_thread, NULL, log_consumer, NULL);

    pthread_t cli_tid;
    pthread_create(&cli_tid, NULL, cli_server, NULL);

    printf("[supervisor] Ready! Commands:\n");
    printf("  ./engine start <id> <rootfs>\n");
    printf("  ./engine ps\n");
    printf("  ./engine stop <id>\n");
    printf("  ./engine logs <id>\n");

    while (supervisor_running) {
        sleep(1);
        while (waitpid(-1, NULL, WNOHANG) > 0);
    }
    printf("[supervisor] Shutting down cleanly...\n");
    supervisor_running = 0;
    pthread_cond_broadcast(&log_buffer.not_empty);
    pthread_join(log_consumer_thread, NULL);
    pthread_cancel(cli_tid);
    printf("[supervisor] Done.\n");
}

void send_command(const char *msg) {
    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    struct sockaddr_un addr;
    memset(&addr,0,sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, SOCKET_PATH, sizeof(addr.sun_path)-1);
    if (connect(fd,(struct sockaddr*)&addr,sizeof(addr))<0) {
        fprintf(stderr,"Cannot connect — is supervisor running?\n"); exit(1);
    }
    write(fd, msg, strlen(msg));
    shutdown(fd, SHUT_WR);
    char buf[4096]={0}; ssize_t n;
    while ((n=read(fd,buf,sizeof(buf)-1))>0) fwrite(buf,1,n,stdout);
    close(fd);
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage:\n"
               "  sudo ./engine supervisor <rootfs>\n"
               "  sudo ./engine start <id> <rootfs>\n"
               "  sudo ./engine run   <id> <rootfs>\n"
               "  sudo ./engine ps\n"
               "  sudo ./engine stop  <id>\n"
               "  sudo ./engine logs  <id>\n");
        return 1;
    }
    if (strcmp(argv[1],"supervisor")==0) {
        if (argc<3){fprintf(stderr,"Need rootfs\n");return 1;}
        run_supervisor(argv[2]);
    } else if (strcmp(argv[1],"start")==0) {
        if (argc<4){fprintf(stderr,"Need id and rootfs\n");return 1;}
        char msg[512];
        snprintf(msg,sizeof(msg),"start %s %s %s",
                 argv[2], argv[3],
                 argc>=5?argv[4]:"echo hello");
        send_command(msg);
    } else if (strcmp(argv[1],"run")==0) {
        if (argc<4){fprintf(stderr,"Need id and rootfs\n");return 1;}
        launch_container(argv[2],argv[3],
                         argc>=5?argv[4]:"/bin/sh",1,128,256);
    } else if (strcmp(argv[1],"ps")==0) {
        send_command("ps");
    } else if (strcmp(argv[1],"stop")==0) {
        if (argc<3){fprintf(stderr,"Need id\n");return 1;}
        char msg[256]; snprintf(msg,sizeof(msg),"stop %s",argv[2]);
        send_command(msg);
    } else if (strcmp(argv[1],"logs")==0) {
        if (argc<3){fprintf(stderr,"Need id\n");return 1;}
        char msg[256]; snprintf(msg,sizeof(msg),"logs %s",argv[2]);
        send_command(msg);
    } else {
        fprintf(stderr,"Unknown: %s\n",argv[1]); return 1;
    }
    return 0;
}
